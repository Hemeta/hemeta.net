import IDO from '../views/IDO';

function App() {
  return <IDO />;
}

export default App;
