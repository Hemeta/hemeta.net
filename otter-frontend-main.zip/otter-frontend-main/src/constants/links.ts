export const DiscordLink = 'https://discord.gg/otterclam';

export const TwitterLink = 'https://twitter.com/otterclam';

export const DocsLink = 'https://docs.otterclam.finance';

export const GithubLink = 'https://github.com/OtterClam';

export const MediumLink = 'https://otterclam.medium.com/';
